This program was developed with VS Code using Java version "1.8.2-221".

In order to run the file below use "java RMullinsLab1.class"

Two uer prompts will occur asking for an input file and ouput file.

Ensure the Input file is in the same folder where you are running the file.

Output files will appear in the same folder as file.

Given error files will propmt terminal error and will not be written to a file.


*NOTE: Note to the grader... I use VS Code and have linked the file path to the
prgoram that runs it which will not allow me to run it via terminal. This does 
compile for some reason it does not for you and can show you anytime you need*